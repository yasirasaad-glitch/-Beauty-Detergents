package com.maysalreem.sales

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaterialTheme { SalesApp(this) } } }
}
data class Offer(val buy:Int,val gift:Int)
data class Product(val id:Long,val name:String,val size:String,val price:Int,val cost:Int,val offers:List<Offer>,val active:Boolean=true)
data class Order(val customer:String,val rep:String,val product:String,val paid:Int,val gift:Int,val total:Int)

class Store(private val c:Context){
 private val p=c.getSharedPreferences("mays_sales",Context.MODE_PRIVATE)
 fun loadProducts():MutableList<Product>{ val s=p.getString("products",null)?:return defaults(); return try{ val a=JSONArray(s); MutableList(a.length()){i-> val o=a.getJSONObject(i); val os=o.getJSONArray("offers"); Product(o.getLong("id"),o.getString("name"),o.getString("size"),o.getInt("price"),o.optInt("cost"),List(os.length()){j->val x=os.getJSONObject(j);Offer(x.getInt("buy"),x.getInt("gift"))},o.optBoolean("active",true)) } }catch(e:Exception){defaults()} }
 fun saveProducts(xs:List<Product>){val a=JSONArray();xs.forEach{x->val o=JSONObject();o.put("id",x.id);o.put("name",x.name);o.put("size",x.size);o.put("price",x.price);o.put("cost",x.cost);o.put("active",x.active);val os=JSONArray();x.offers.forEach{q->os.put(JSONObject().put("buy",q.buy).put("gift",q.gift))};o.put("offers",os);a.put(o)};p.edit().putString("products",a.toString()).apply()}
 fun loadOrders():MutableList<Order>{val a=JSONArray(p.getString("orders","[]"));return MutableList(a.length()){i->val o=a.getJSONObject(i);Order(o.getString("customer"),o.getString("rep"),o.getString("product"),o.getInt("paid"),o.getInt("gift"),o.getInt("total"))}}
 fun saveOrders(xs:List<Order>){val a=JSONArray();xs.forEach{x->a.put(JSONObject().put("customer",x.customer).put("rep",x.rep).put("product",x.product).put("paid",x.paid).put("gift",x.gift).put("total",x.total))};p.edit().putString("orders",a.toString()).apply()}
 private fun defaults()= mutableListOf(Product(1,"سائل غسيل الأطباق","الكبير",12000,9250,listOf(Offer(15,1),Offer(25,2),Offer(50,5))),Product(2,"سائل غسيل الأطباق","10 لتر",6000,4300,listOf(Offer(15,1),Offer(25,2),Offer(50,5))))
}
fun gifts(q:Int,offers:List<Offer>):Int{var left=q;var g=0;offers.sortedByDescending{it.buy}.forEach{g+=(left/it.buy)*it.gift;left%=it.buy};return g}
@Composable fun SalesApp(ctx:Context){val store=remember{Store(ctx)};var products by remember{mutableStateOf(store.loadProducts())};var orders by remember{mutableStateOf(store.loadOrders())};var tab by remember{mutableIntStateOf(0)};Scaffold(bottomBar={NavigationBar{listOf("طلب جديد","المنتجات","التقارير").forEachIndexed{i,s->NavigationBarItem(tab==i,{tab=i},{Text(s.take(1))},label={Text(s)})}}}){pad->Box(Modifier.padding(pad)){when(tab){0->OrderScreen(products){orders=(orders+it).toMutableList();store.saveOrders(orders)};1->ProductsScreen(products){products=it;store.saveProducts(it)};else->ReportsScreen(orders)}}}}
@Composable fun OrderScreen(products:List<Product>,save:(Order)->Unit){var customer by remember{mutableStateOf("")};var rep by remember{mutableStateOf("")};var ix by remember{mutableIntStateOf(0)};var qty by remember{mutableStateOf("15")};var msg by remember{mutableStateOf("")};val active=products.filter{it.active};if(active.isEmpty()){Text("لا توجد منتجات فعالة. أضف منتجاً من الإدارة.",Modifier.padding(20.dp));return};if(ix>active.lastIndex)ix=0;val x=active[ix];val q=qty.toIntOrNull()?:0;val g=gifts(q,x.offers);val nf=NumberFormat.getNumberInstance(Locale.US);Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())){Text("ميس الريم | طلب جديد",24.sp,fontWeight=FontWeight.Bold);OutlinedTextField(customer,{customer=it},label={Text("الزبون / المحل")},modifier=Modifier.fillMaxWidth());OutlinedTextField(rep,{rep=it},label={Text("المندوب")},modifier=Modifier.fillMaxWidth());Text("اختر المنتج",fontWeight=FontWeight.Bold);active.forEachIndexed{i,p->Row{RadioButton(ix==i,{ix=i});Text("${p.name} - ${p.size} | ${nf.format(p.price)} د.ع",Modifier.padding(top=12.dp))}};OutlinedTextField(qty,{qty=it.filter(Char::isDigit)},label={Text("الكمية المدفوعة")},modifier=Modifier.fillMaxWidth());Card(Modifier.fillMaxWidth().padding(vertical=12.dp)){Column(Modifier.padding(16.dp)){Text("الهدية: $g");Text("إجمالي المستلم: ${q+g}");Text("الفاتورة: ${nf.format(q*x.price)} د.ع");Text("العروض: "+x.offers.joinToString(" • "){"${it.buy}+${it.gift}"})}};Button({if(customer.isBlank()||rep.isBlank()||q<=0)msg="أكمل بيانات الطلب" else{save(Order(customer,rep,"${x.name} ${x.size}",q,g,q*x.price));msg="تم تسجيل الطلب بنجاح"}},Modifier.fillMaxWidth()){Text("تسجيل الطلب")};Text(msg,fontWeight=FontWeight.Bold)}}
@Composable fun ProductsScreen(products:MutableList<Product>,save:(MutableList<Product>)->Unit){var name by remember{mutableStateOf("")};var size by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var offers by remember{mutableStateOf("15+1,25+2,50+5")};Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())){Text("إدارة المنتجات والعروض",24.sp,fontWeight=FontWeight.Bold);Text("يمكن للمدير إضافة أي منتج وعروض مختلفة له.");OutlinedTextField(name,{name=it},label={Text("اسم المنتج")},modifier=Modifier.fillMaxWidth());OutlinedTextField(size,{size=it},label={Text("الحجم")},modifier=Modifier.fillMaxWidth());OutlinedTextField(price,{price=it.filter(Char::isDigit)},label={Text("سعر البيع")},modifier=Modifier.fillMaxWidth());OutlinedTextField(cost,{cost=it.filter(Char::isDigit)},label={Text("التكلفة (اختياري)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(offers,{offers=it},label={Text("العروض مثال: 15+1,25+2,50+5")},modifier=Modifier.fillMaxWidth());Button({val pr=price.toIntOrNull();if(name.isNotBlank()&&pr!=null){val os=offers.split(",").mapNotNull{z->val v=z.trim().split("+");if(v.size==2) v[0].toIntOrNull()?.let{b->v[1].toIntOrNull()?.let{g->Offer(b,g)}} else null};save((products+Product(System.currentTimeMillis(),name,size,pr,cost.toIntOrNull()?:0,os)).toMutableList());name="";size="";price=""}},Modifier.fillMaxWidth()){Text("إضافة المنتج")};HorizontalDivider(Modifier.padding(vertical=12.dp));products.forEach{x->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(12.dp)){Text("${x.name} — ${x.size}",fontWeight=FontWeight.Bold);Text("السعر: ${x.price} د.ع | العروض: ${x.offers.joinToString{ "${it.buy}+${it.gift}" }}");Row{Button({save(products.map{if(it.id==x.id)it.copy(active=!it.active)else it}.toMutableList())}){Text(if(x.active)"إيقاف" else "تفعيل")};Spacer(Modifier.width(8.dp));OutlinedButton({save(products.filterNot{it.id==x.id}.toMutableList())}){Text("حذف")}}}}}}
@Composable fun ReportsScreen(orders:List<Order>){val nf=NumberFormat.getNumberInstance(Locale.US);Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())){Text("التقارير",24.sp,fontWeight=FontWeight.Bold);Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("عدد الطلبات: ${orders.size}");Text("إجمالي المبيعات: ${nf.format(orders.sumOf{it.total})} د.ع");Text("إجمالي المجاني: ${orders.sumOf{it.gift}} جلكان")}};orders.asReversed().forEach{x->Text("${x.customer} | ${x.rep} | ${x.product} | ${x.paid}+${x.gift} | ${nf.format(x.total)} د.ع",Modifier.padding(vertical=6.dp));HorizontalDivider()}}}
